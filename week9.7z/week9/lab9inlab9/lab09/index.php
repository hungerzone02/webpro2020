<html>
<head>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>

    <?php require_once "header.php"; ?>

    <div class="main-content">
		<div class="logo">
            <img title="Captain Marvel" src="images/logo.jpg">
        </div>
	</div>

    <?php include_once "footer.php"?>

</body>
</html>