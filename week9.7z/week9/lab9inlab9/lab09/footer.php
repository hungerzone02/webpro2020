<div class="footer">
    Copyright ©2012 College of Arts, Media and Technology, Chiang Mai University
</div>
